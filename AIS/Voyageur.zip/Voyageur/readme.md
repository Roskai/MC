# AIS
Voici le repertoire du projet AIS. 

Comme expliqué dans le rapport,des modifications ont été apporté au code et paticulièrement dans le fichier `params.h`. 

Le fichier `calculStat.sh` est le script bash qui automatise le processus de test. Il va lancer 20 fois ais.
